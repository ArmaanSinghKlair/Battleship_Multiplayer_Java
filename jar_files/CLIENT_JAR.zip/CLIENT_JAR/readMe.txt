1. Enter you username
2. Click login
3. Wait until opponent connects
4. Chat / play battleship!!!
5. Place all ships, then start hitting opponent's ships
6. If you hit any ship, your turn, if not opponent's turn
7. Points increase as you sink opponent's ships
8. In the end, decide you want to play more or not