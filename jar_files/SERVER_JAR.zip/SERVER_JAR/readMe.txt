1. Start server
2. Server listens and connects players automatically